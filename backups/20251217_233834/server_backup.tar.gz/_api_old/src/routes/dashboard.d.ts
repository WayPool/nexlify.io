/**
 * Dashboard Routes
 *
 * API endpoints for modular dashboard widgets.
 * Returns widget configuration and data based on active modules.
 */
import { Router } from 'express';
export declare const dashboardRoutes: Router;
//# sourceMappingURL=dashboard.d.ts.map