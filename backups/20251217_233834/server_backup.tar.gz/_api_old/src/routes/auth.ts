/**
 * Authentication routes.
 */

import { Router } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import { generateToken, generateRefreshToken } from '../middleware/auth.js';
import { errors } from '../middleware/error-handler.js';

export const authRoutes = Router();

// Validation schemas
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  companyName: z.string().min(2),
});

const refreshSchema = z.object({
  refresh_token: z.string(),
});

/**
 * POST /api/auth/login
 */
authRoutes.post('/login', async (req, res, next) => {
  try {
    const { email, password } = loginSchema.parse(req.body);

    // TODO: Look up user in database
    // For demo, accept any password with 8+ chars

    const userId = uuid();
    const tenantId = uuid();

    // Generate tokens
    const token = generateToken({
      id: userId,
      email,
      tenant_id: tenantId,
      roles: ['admin'],
      permissions: ['*'],
    });

    const refreshToken = generateRefreshToken(userId);

    // Extract name from email for demo
    const namePart = email.split('@')[0];
    const firstName = namePart.charAt(0).toUpperCase() + namePart.slice(1);

    res.json({
      token,
      refresh_token: refreshToken,
      user: {
        id: userId,
        email,
        firstName,
        lastName: 'Usuario',
        role: 'admin',
        tenantId,
        tenantName: 'Demo Company',
        permissions: ['*'],
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/auth/register
 */
authRoutes.post('/register', async (req, res, next) => {
  try {
    const { email, password, firstName, lastName, companyName } = registerSchema.parse(req.body);

    // TODO: Check if user exists in DB
    // TODO: Create tenant and user in DB

    const passwordHash = await bcrypt.hash(password, 10);
    const userId = uuid();
    const tenantId = uuid();

    // Generate token for auto-login after registration
    const token = generateToken({
      id: userId,
      email,
      tenant_id: tenantId,
      roles: ['admin'],
      permissions: ['*'],
    });

    const refreshToken = generateRefreshToken(userId);

    res.status(201).json({
      token,
      refresh_token: refreshToken,
      user: {
        id: userId,
        email,
        firstName,
        lastName,
        role: 'admin',
        tenantId,
        tenantName: companyName,
        permissions: ['*'],
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/auth/refresh
 */
authRoutes.post('/refresh', async (req, res, next) => {
  try {
    const { refresh_token } = refreshSchema.parse(req.body);

    // TODO: Verify refresh token and get user
    // TODO: Check if token is revoked

    // Mock response
    const token = generateToken({
      id: uuid(),
      email: 'user@example.com',
      tenant_id: uuid(),
      roles: ['admin'],
      permissions: ['*'],
    });

    res.json({ token });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/auth/logout
 */
authRoutes.post('/logout', async (req, res, next) => {
  try {
    // TODO: Revoke refresh token

    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/auth/forgot-password
 */
authRoutes.post('/forgot-password', async (req, res, next) => {
  try {
    const { email } = z.object({ email: z.string().email() }).parse(req.body);

    // TODO: Generate reset token and send email

    res.json({
      message: 'If an account exists with this email, a password reset link has been sent.',
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/auth/reset-password
 */
authRoutes.post('/reset-password', async (req, res, next) => {
  try {
    const { token, password } = z
      .object({
        token: z.string(),
        password: z.string().min(8),
      })
      .parse(req.body);

    // TODO: Verify reset token and update password

    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/auth/google
 * Redirect to Google OAuth
 */
authRoutes.get('/google', (req, res) => {
  // TODO: Implement Google OAuth redirect
  res.redirect('https://accounts.google.com/o/oauth2/v2/auth');
});

/**
 * GET /api/auth/google/callback
 * Handle Google OAuth callback
 */
authRoutes.get('/google/callback', async (req, res, next) => {
  try {
    // TODO: Handle Google OAuth callback
    // - Exchange code for tokens
    // - Get user info
    // - Create/link user account
    // - Generate JWT

    res.redirect('http://localhost:3000/auth/callback');
  } catch (error) {
    next(error);
  }
});
