/**
 * Banking Module Routes
 *
 * API endpoints for bank connections, transactions, and anomaly detection.
 */
import { Router } from 'express';
export declare const bankingRoutes: Router;
//# sourceMappingURL=banking.d.ts.map