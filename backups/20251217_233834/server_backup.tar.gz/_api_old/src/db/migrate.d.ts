/**
 * Database migration runner.
 */
export {};
//# sourceMappingURL=migrate.d.ts.map