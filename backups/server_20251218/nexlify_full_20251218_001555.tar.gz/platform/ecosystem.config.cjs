module.exports = {
  apps: [{
    name: 'platform-api',
    script: './node_modules/.pnpm/tsx@4.21.0/node_modules/tsx/dist/cli.mjs',
    args: 'apps/api/src/index.ts',
    cwd: '/var/www/vhosts/nexlify.io/platform',
    interpreter: '/opt/plesk/node/20/bin/node',
    env: {
      NODE_ENV: 'production',
      PORT: 3001,
      PATH: '/opt/plesk/node/20/bin:/var/www/vhosts/nexlify.io/.local/share/pnpm'
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    error_file: '/var/www/vhosts/nexlify.io/logs/api-error.log',
    out_file: '/var/www/vhosts/nexlify.io/logs/api-out.log',
    log_file: '/var/www/vhosts/nexlify.io/logs/api-combined.log',
    time: true
  }]
};
