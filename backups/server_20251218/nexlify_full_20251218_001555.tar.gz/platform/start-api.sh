#!/bin/bash
export PATH=/opt/plesk/node/20/bin:$PATH
cd /var/www/vhosts/nexlify.io/platform

# Kill existing process
pkill -f 'tsx apps/api' 2>/dev/null

# Start API
nohup ./apps/api/node_modules/.bin/tsx apps/api/src/index.ts > /var/www/vhosts/nexlify.io/logs/api.log 2>&1 &

echo "API started with PID $!"
