"use strict";
/**
 * Core Type Definitions
 *
 * This file contains all shared types used across the platform.
 * All modules should import types from @platform/core/types
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=index.js.map