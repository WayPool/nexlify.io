import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Boxes,
  Search,
  Settings,
  Power,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Shield,
  FileText,
  Users,
  CreditCard,
  Scale,
  Building2,
} from 'lucide-react';
import clsx from 'clsx';

interface Module {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  status: 'active' | 'inactive' | 'coming_soon';
  version: string;
  detectors: number;
  risksFound: number;
  lastRun: string;
  category: string;
}

const mockModules: Module[] = [
  {
    id: 'payroll',
    name: 'Cumplimiento de Nóminas',
    description: 'Detecta violaciones de horas extra, vencimientos de contratos y anomalías salariales.',
    icon: Users,
    status: 'active',
    version: '1.2.0',
    detectors: 3,
    risksFound: 24,
    lastRun: '2024-01-15T10:30:00Z',
    category: 'RRHH',
  },
  {
    id: 'gdpr',
    name: 'Cumplimiento GDPR',
    description: 'Monitorea consentimientos, brechas de datos y derechos de los interesados.',
    icon: Shield,
    status: 'active',
    version: '2.1.0',
    detectors: 5,
    risksFound: 12,
    lastRun: '2024-01-15T09:00:00Z',
    category: 'Privacidad',
  },
  {
    id: 'fiscal',
    name: 'Cumplimiento Fiscal',
    description: 'Gestiona obligaciones fiscales, plazos y declaraciones.',
    icon: FileText,
    status: 'active',
    version: '1.0.3',
    detectors: 4,
    risksFound: 8,
    lastRun: '2024-01-15T08:00:00Z',
    category: 'Finanzas',
  },
  {
    id: 'aml',
    name: 'Anti-Blanqueo (AML)',
    description: 'Detecta transacciones sospechosas y patrones de blanqueo de capitales.',
    icon: CreditCard,
    status: 'inactive',
    version: '1.5.0',
    detectors: 6,
    risksFound: 0,
    lastRun: '',
    category: 'Finanzas',
  },
  {
    id: 'contracts',
    name: 'Gestión de Contratos',
    description: 'Monitorea vencimientos, cláusulas de riesgo y obligaciones contractuales.',
    icon: Scale,
    status: 'coming_soon',
    version: '0.9.0',
    detectors: 0,
    risksFound: 0,
    lastRun: '',
    category: 'Legal',
  },
  {
    id: 'suppliers',
    name: 'Riesgo de Proveedores',
    description: 'Evalúa la salud financiera y cumplimiento de proveedores críticos.',
    icon: Building2,
    status: 'coming_soon',
    version: '0.8.0',
    detectors: 0,
    risksFound: 0,
    lastRun: '',
    category: 'Operaciones',
  },
];

const statusConfig = {
  active: { label: 'Activo', color: 'green', icon: CheckCircle2 },
  inactive: { label: 'Inactivo', color: 'slate', icon: Power },
  coming_soon: { label: 'Próximamente', color: 'purple', icon: Clock },
};

export default function Modules() {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const categories = [...new Set(mockModules.map((m) => m.category))];

  const filteredModules = mockModules.filter((module) => {
    const matchesSearch = module.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      module.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || module.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const activeModules = mockModules.filter((m) => m.status === 'active').length;
  const totalDetectors = mockModules.reduce((sum, m) => sum + m.detectors, 0);
  const totalRisks = mockModules.reduce((sum, m) => sum + m.risksFound, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            Módulos
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            Gestiona los módulos de detección de riesgos
          </p>
        </div>
        <button className="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-xl text-sm font-medium transition-colors flex items-center gap-2">
          <Boxes className="w-4 h-4" />
          Explorar Marketplace
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{activeModules}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">Módulos activos</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
              <Shield className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{totalDetectors}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">Detectores totales</p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-100 dark:bg-amber-900/30 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{totalRisks}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">Riesgos detectados</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar módulos..."
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none text-slate-900 dark:text-white"
          />
        </div>
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="px-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-primary-500 outline-none"
        >
          <option value="all">Todas las categorías</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      {/* Module Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredModules.map((module, index) => {
          const status = statusConfig[module.status];
          const StatusIcon = status.icon;
          const ModuleIcon = module.icon;

          return (
            <motion.div
              key={module.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={clsx(
                'bg-white dark:bg-slate-900 rounded-2xl border overflow-hidden transition-all hover:shadow-lg',
                module.status === 'coming_soon'
                  ? 'border-slate-200 dark:border-slate-800 opacity-75'
                  : 'border-slate-200 dark:border-slate-800'
              )}
            >
              <div className="p-6">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div
                    className={clsx(
                      'p-3 rounded-xl',
                      module.status === 'active' && 'bg-primary-100 dark:bg-primary-900/30',
                      module.status === 'inactive' && 'bg-slate-100 dark:bg-slate-800',
                      module.status === 'coming_soon' && 'bg-purple-100 dark:bg-purple-900/30'
                    )}
                  >
                    <ModuleIcon
                      className={clsx(
                        'w-6 h-6',
                        module.status === 'active' && 'text-primary-600 dark:text-primary-400',
                        module.status === 'inactive' && 'text-slate-500',
                        module.status === 'coming_soon' && 'text-purple-600 dark:text-purple-400'
                      )}
                    />
                  </div>
                  <div
                    className={clsx(
                      'flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium',
                      status.color === 'green' && 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400',
                      status.color === 'slate' && 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400',
                      status.color === 'purple' && 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400'
                    )}
                  >
                    <StatusIcon className="w-3 h-3" />
                    {status.label}
                  </div>
                </div>

                {/* Content */}
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                  {module.name}
                </h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
                  {module.description}
                </p>

                {/* Stats */}
                {module.status !== 'coming_soon' && (
                  <div className="flex items-center gap-4 mb-4">
                    <div>
                      <p className="text-lg font-bold text-slate-900 dark:text-white">
                        {module.detectors}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Detectores</p>
                    </div>
                    <div className="w-px h-8 bg-slate-200 dark:bg-slate-700" />
                    <div>
                      <p className="text-lg font-bold text-slate-900 dark:text-white">
                        {module.risksFound}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Riesgos</p>
                    </div>
                    <div className="w-px h-8 bg-slate-200 dark:bg-slate-700" />
                    <div>
                      <p className="text-lg font-bold text-slate-900 dark:text-white">
                        v{module.version}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Versión</p>
                    </div>
                  </div>
                )}

                {/* Category Badge */}
                <div className="mb-4">
                  <span className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-xs rounded-lg">
                    {module.category}
                  </span>
                </div>
              </div>

              {/* Footer */}
              <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800">
                {module.status === 'active' ? (
                  <div className="flex items-center justify-between">
                    <button className="text-sm text-primary-600 dark:text-primary-400 font-medium flex items-center gap-1 hover:underline">
                      Configurar <Settings className="w-4 h-4" />
                    </button>
                    <button className="text-sm text-slate-500 hover:text-red-500 font-medium flex items-center gap-1 transition-colors">
                      <Power className="w-4 h-4" />
                      Desactivar
                    </button>
                  </div>
                ) : module.status === 'inactive' ? (
                  <button className="w-full py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2">
                    <Power className="w-4 h-4" />
                    Activar Módulo
                  </button>
                ) : (
                  <button className="w-full py-2 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 rounded-lg text-sm font-medium flex items-center justify-center gap-2 cursor-not-allowed">
                    <Clock className="w-4 h-4" />
                    En Desarrollo
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
