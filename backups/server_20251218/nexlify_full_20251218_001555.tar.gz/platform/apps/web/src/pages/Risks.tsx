import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  AlertTriangle,
  Clock,
  User,
  Building2,
  ChevronRight,
  X,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Shield,
  FileText,
  ExternalLink,
} from 'lucide-react';
import clsx from 'clsx';

interface Risk {
  id: string;
  title: string;
  description: string;
  module: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  status: 'open' | 'in_progress' | 'resolved' | 'dismissed';
  entity: { type: string; name: string };
  detectedAt: string;
  impact: number;
  likelihood: number;
  actions: string[];
}

// Mock data
const mockRisks: Risk[] = [
  {
    id: '1',
    title: 'Violación de horas extra detectada',
    description: 'El empleado ha excedido el umbral legal de horas extra. Esto puede resultar en violaciones de la ley laboral y posibles multas.',
    module: 'Nóminas',
    severity: 'high',
    status: 'open',
    entity: { type: 'employee', name: 'María García' },
    detectedAt: '2024-01-15T10:30:00Z',
    impact: 15000,
    likelihood: 0.85,
    actions: [
      'Revisar la carga de trabajo del empleado y redistribuir tareas',
      'Aprobar tiempo compensatorio',
      'Documentar justificación del negocio si las horas extra son necesarias',
      'Revisar capacidad del equipo y considerar contratación',
    ],
  },
  {
    id: '2',
    title: 'Contrato próximo a vencer',
    description: 'El contrato de trabajo está a punto de vencer sin una renovación en proceso.',
    module: 'Nóminas',
    severity: 'medium',
    status: 'in_progress',
    entity: { type: 'employee', name: 'Carlos López' },
    detectedAt: '2024-01-14T08:15:00Z',
    impact: 8000,
    likelihood: 0.95,
    actions: [
      'Revisar el desempeño del empleado y decidir sobre renovación',
      'Preparar documentación de renovación o terminación',
      'Si no se renueva, asegurar el período de aviso adecuado',
    ],
  },
  {
    id: '3',
    title: 'Brecha salarial de género detectada',
    description: 'Se detectó una brecha salarial significativa entre géneros para el mismo rol en el departamento de Ingeniería.',
    module: 'Nóminas',
    severity: 'critical',
    status: 'open',
    entity: { type: 'department', name: 'Ingeniería' },
    detectedAt: '2024-01-13T14:45:00Z',
    impact: 187515,
    likelihood: 0.95,
    actions: [
      'Realizar análisis detallado de equidad salarial',
      'Revisar clasificación de puestos y bandas salariales',
      'Desarrollar plan de remediación',
      'Documentar hallazgos y acciones para cumplimiento',
    ],
  },
  {
    id: '4',
    title: 'Consentimiento GDPR expirado',
    description: 'El consentimiento de procesamiento de datos ha expirado para un conjunto de clientes.',
    module: 'GDPR',
    severity: 'high',
    status: 'open',
    entity: { type: 'dataset', name: 'Base de clientes Marketing' },
    detectedAt: '2024-01-12T09:00:00Z',
    impact: 50000,
    likelihood: 0.7,
    actions: [
      'Pausar campañas de marketing activas',
      'Enviar solicitud de renovación de consentimiento',
      'Actualizar registros de consentimiento',
    ],
  },
  {
    id: '5',
    title: 'Declaración fiscal pendiente',
    description: 'La declaración trimestral de IVA está próxima a vencer.',
    module: 'Fiscal',
    severity: 'medium',
    status: 'resolved',
    entity: { type: 'obligation', name: 'IVA Q4 2024' },
    detectedAt: '2024-01-10T11:30:00Z',
    impact: 12000,
    likelihood: 0.6,
    actions: [
      'Preparar documentación fiscal',
      'Revisar facturas pendientes',
      'Presentar declaración antes del plazo',
    ],
  },
];

const severityConfig = {
  critical: { label: 'Crítico', color: 'red', bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-700 dark:text-red-400' },
  high: { label: 'Alto', color: 'orange', bg: 'bg-orange-100 dark:bg-orange-900/30', text: 'text-orange-700 dark:text-orange-400' },
  medium: { label: 'Medio', color: 'amber', bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-700 dark:text-amber-400' },
  low: { label: 'Bajo', color: 'green', bg: 'bg-green-100 dark:bg-green-900/30', text: 'text-green-700 dark:text-green-400' },
};

const statusConfig = {
  open: { label: 'Abierto', icon: AlertTriangle, color: 'text-amber-500' },
  in_progress: { label: 'En Progreso', icon: Clock, color: 'text-blue-500' },
  resolved: { label: 'Resuelto', icon: CheckCircle2, color: 'text-green-500' },
  dismissed: { label: 'Descartado', icon: XCircle, color: 'text-slate-500' },
};

export default function Risks() {
  const [selectedRisk, setSelectedRisk] = useState<Risk | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [moduleFilter, setModuleFilter] = useState<string>('all');

  const filteredRisks = mockRisks.filter((risk) => {
    const matchesSearch = risk.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      risk.entity.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSeverity = severityFilter === 'all' || risk.severity === severityFilter;
    const matchesStatus = statusFilter === 'all' || risk.status === statusFilter;
    const matchesModule = moduleFilter === 'all' || risk.module === moduleFilter;
    return matchesSearch && matchesSeverity && matchesStatus && matchesModule;
  });

  const modules = [...new Set(mockRisks.map((r) => r.module))];

  return (
    <div className="flex h-[calc(100vh-7rem)]">
      {/* Main List */}
      <div className={clsx('flex-1 flex flex-col', selectedRisk && 'lg:mr-[450px]')}>
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-1">
            Gestión de Riesgos
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            {filteredRisks.length} riesgos encontrados
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar riesgos..."
              className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-primary-500 outline-none text-slate-900 dark:text-white"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="px-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-primary-500 outline-none"
            >
              <option value="all">Todas las severidades</option>
              <option value="critical">Crítico</option>
              <option value="high">Alto</option>
              <option value="medium">Medio</option>
              <option value="low">Bajo</option>
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-primary-500 outline-none"
            >
              <option value="all">Todos los estados</option>
              <option value="open">Abierto</option>
              <option value="in_progress">En Progreso</option>
              <option value="resolved">Resuelto</option>
              <option value="dismissed">Descartado</option>
            </select>
            <select
              value={moduleFilter}
              onChange={(e) => setModuleFilter(e.target.value)}
              className="px-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-primary-500 outline-none"
            >
              <option value="all">Todos los módulos</option>
              {modules.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Risk List */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin">
          {filteredRisks.map((risk) => {
            const severity = severityConfig[risk.severity];
            const status = statusConfig[risk.status];
            const StatusIcon = status.icon;

            return (
              <motion.div
                key={risk.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                onClick={() => setSelectedRisk(risk)}
                className={clsx(
                  'p-4 bg-white dark:bg-slate-900 rounded-xl border cursor-pointer transition-all',
                  selectedRisk?.id === risk.id
                    ? 'border-primary-500 ring-2 ring-primary-500/20'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                )}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={clsx(
                      'w-1 h-full min-h-[60px] rounded-full flex-shrink-0',
                      risk.severity === 'critical' && 'bg-red-500',
                      risk.severity === 'high' && 'bg-orange-500',
                      risk.severity === 'medium' && 'bg-amber-500',
                      risk.severity === 'low' && 'bg-green-500'
                    )}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-semibold text-slate-900 dark:text-white mb-1">
                          {risk.title}
                        </h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2">
                          {risk.description}
                        </p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0" />
                    </div>
                    <div className="flex flex-wrap items-center gap-3 mt-3">
                      <span className={clsx('px-2.5 py-1 rounded-lg text-xs font-medium', severity.bg, severity.text)}>
                        {severity.label}
                      </span>
                      <div className={clsx('flex items-center gap-1.5 text-sm', status.color)}>
                        <StatusIcon className="w-4 h-4" />
                        {status.label}
                      </div>
                      <span className="text-sm text-slate-500 dark:text-slate-400">
                        {risk.module}
                      </span>
                      <span className="text-sm text-slate-500 dark:text-slate-400">
                        {risk.entity.name}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Detail Panel */}
      <AnimatePresence>
        {selectedRisk && (
          <motion.div
            initial={{ x: 450, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 450, opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-16 bottom-0 w-[450px] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 overflow-y-auto z-30"
          >
            <div className="p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span
                      className={clsx(
                        'px-2.5 py-1 rounded-lg text-xs font-medium',
                        severityConfig[selectedRisk.severity].bg,
                        severityConfig[selectedRisk.severity].text
                      )}
                    >
                      {severityConfig[selectedRisk.severity].label}
                    </span>
                    <span className="text-sm text-slate-500 dark:text-slate-400">
                      #{selectedRisk.id}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                    {selectedRisk.title}
                  </h2>
                </div>
                <button
                  onClick={() => setSelectedRisk(null)}
                  className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              {/* Status */}
              <div className="flex items-center gap-4 mb-6">
                {Object.entries(statusConfig).map(([key, config]) => {
                  const Icon = config.icon;
                  const isActive = selectedRisk.status === key;
                  return (
                    <button
                      key={key}
                      className={clsx(
                        'flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                        isActive
                          ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-400'
                          : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                      )}
                    >
                      <Icon className="w-4 h-4" />
                      {config.label}
                    </button>
                  );
                })}
              </div>

              {/* Description */}
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-2">
                  Descripción
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {selectedRisk.description}
                </p>
              </div>

              {/* Details */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 mb-1">
                    <Shield className="w-4 h-4" />
                    <span className="text-xs">Impacto Estimado</span>
                  </div>
                  <p className="text-lg font-bold text-slate-900 dark:text-white">
                    €{selectedRisk.impact.toLocaleString()}
                  </p>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 mb-1">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="text-xs">Probabilidad</span>
                  </div>
                  <p className="text-lg font-bold text-slate-900 dark:text-white">
                    {Math.round(selectedRisk.likelihood * 100)}%
                  </p>
                </div>
              </div>

              {/* Entity */}
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
                  Entidad Afectada
                </h3>
                <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                  {selectedRisk.entity.type === 'employee' ? (
                    <User className="w-5 h-5 text-slate-400" />
                  ) : (
                    <Building2 className="w-5 h-5 text-slate-400" />
                  )}
                  <div>
                    <p className="font-medium text-slate-900 dark:text-white">
                      {selectedRisk.entity.name}
                    </p>
                    <p className="text-xs text-slate-500 capitalize">
                      {selectedRisk.entity.type}
                    </p>
                  </div>
                </div>
              </div>

              {/* Recommended Actions */}
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
                  Acciones Recomendadas
                </h3>
                <div className="space-y-2">
                  {selectedRisk.actions.map((action, index) => (
                    <div
                      key={index}
                      className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl"
                    >
                      <div className="w-6 h-6 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-primary-600 dark:text-primary-400">
                          {index + 1}
                        </span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400">{action}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <button className="flex-1 py-3 px-4 bg-primary-500 hover:bg-primary-600 text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  Resolver
                </button>
                <button className="py-3 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-xl transition-colors">
                  <MessageSquare className="w-5 h-5" />
                </button>
                <button className="py-3 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold rounded-xl transition-colors">
                  <FileText className="w-5 h-5" />
                </button>
              </div>

              {/* Blockchain Proof */}
              <div className="mt-6 p-4 bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl border border-primary-200 dark:border-primary-800">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-primary-600 dark:text-primary-400" />
                  <span className="text-sm font-semibold text-primary-700 dark:text-primary-400">
                    Trazabilidad Blockchain
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mb-2">
                  Este riesgo está anclado en blockchain para garantizar su inmutabilidad.
                </p>
                <button className="text-xs text-primary-600 dark:text-primary-400 font-medium flex items-center gap-1 hover:underline">
                  Ver prueba <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
