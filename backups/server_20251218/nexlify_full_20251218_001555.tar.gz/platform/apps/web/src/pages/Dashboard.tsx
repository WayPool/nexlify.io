/**
 * Dashboard Page
 *
 * Modular dashboard that renders widgets based on active modules.
 * Widgets are fetched from the API and rendered dynamically.
 */

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, Settings, FileCheck } from 'lucide-react';
import { WidgetRenderer } from '@/components/widgets';
import type { WidgetWithData } from '@/lib/widgets/types';
import { api } from '@/services/api';

interface DashboardResponse {
  widgets: WidgetWithData[];
  lastUpdated: string;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

export default function Dashboard() {
  const [widgets, setWidgets] = useState<WidgetWithData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState('30d');

  const fetchWidgets = useCallback(async () => {
    try {
      const response = await api.get<DashboardResponse>('/dashboard/widgets');
      setWidgets(response.data.widgets);
      setLastUpdated(response.data.lastUpdated);
      setError(null);
    } catch (err) {
      console.error('Error fetching widgets:', err);
      setError('Error al cargar los widgets');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchWidgets();
  }, [fetchWidgets]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchWidgets();
  };

  const handleWidgetRefresh = async (widgetId: string) => {
    try {
      const response = await api.get<WidgetWithData>(`/dashboard/widgets/${widgetId}`);
      setWidgets((prev) =>
        prev.map((w) => (w.id === widgetId ? response.data : w))
      );
    } catch (err) {
      console.error(`Error refreshing widget ${widgetId}:`, err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary-500/30 border-t-primary-500 rounded-full animate-spin" />
          <p className="text-slate-500 dark:text-slate-400">Cargando dashboard...</p>
        </div>
      </div>
    );
  }

  if (error && widgets.length === 0) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
        <div className="text-center">
          <p className="text-slate-600 dark:text-slate-400 mb-4">{error}</p>
          <button
            onClick={handleRefresh}
            className="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-xl text-sm font-medium transition-colors"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  // Group widgets by type for better layout
  const statWidgets = widgets.filter((w) => w.widgetData.type === 'stat');
  const otherWidgets = widgets.filter((w) => w.widgetData.type !== 'stat');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            Panel de Control
          </h1>
          <p className="text-slate-500 dark:text-slate-400">
            Visión general de riesgos y cumplimiento
            {lastUpdated && (
              <span className="text-xs ml-2">
                · Actualizado {new Date(lastUpdated).toLocaleTimeString('es-ES')}
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-600 dark:text-slate-300 focus:ring-2 focus:ring-primary-500 outline-none"
          >
            <option value="7d">Últimos 7 días</option>
            <option value="30d">Últimos 30 días</option>
            <option value="90d">Último trimestre</option>
            <option value="365d">Último año</option>
          </select>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors disabled:opacity-50"
            title="Actualizar"
          >
            <RefreshCw
              className={`w-5 h-5 text-slate-600 dark:text-slate-400 ${
                refreshing ? 'animate-spin' : ''
              }`}
            />
          </button>
          <button className="p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
            <Settings className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </button>
          <button className="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-xl text-sm font-medium transition-colors flex items-center gap-2">
            <FileCheck className="w-4 h-4" />
            <span className="hidden sm:inline">Generar Reporte</span>
          </button>
        </div>
      </div>

      {/* Stat Widgets Row */}
      {statWidgets.length > 0 && (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {statWidgets.map((widget) => (
            <WidgetRenderer
              key={widget.id}
              widget={widget}
              onRefresh={() => handleWidgetRefresh(widget.id)}
            />
          ))}
        </motion.div>
      )}

      {/* Other Widgets Grid */}
      {otherWidgets.length > 0 && (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 lg:grid-cols-4 gap-6"
        >
          {otherWidgets.map((widget) => (
            <WidgetRenderer
              key={widget.id}
              widget={widget}
              onRefresh={() => handleWidgetRefresh(widget.id)}
            />
          ))}
        </motion.div>
      )}

      {/* Empty State */}
      {widgets.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-4">
            <Settings className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
            No hay módulos activos
          </h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-md mb-6">
            Activa módulos desde la sección de configuración para ver widgets en tu dashboard.
          </p>
          <a
            href="/modules"
            className="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-xl text-sm font-medium transition-colors"
          >
            Ir a Módulos
          </a>
        </div>
      )}
    </div>
  );
}
