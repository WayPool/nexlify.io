export { default as Login } from './Login';
export { default as Register } from './Register';
export { default as Dashboard } from './Dashboard';
export { default as Risks } from './Risks';
export { default as Modules } from './Modules';
