#!/bin/bash
# Check if API is running, restart if not
export PATH=/opt/plesk/node/20/bin:$PATH

if ! curl -s http://localhost:3001/api/health > /dev/null 2>&1; then
    echo "[$(date)] API down, restarting..."
    cd /var/www/vhosts/nexlify.io/platform
    pkill -f 'tsx apps/api' 2>/dev/null
    nohup ./apps/api/node_modules/.bin/tsx apps/api/src/index.ts >> /var/www/vhosts/nexlify.io/logs/api.log 2>&1 &
    echo "[$(date)] API restarted with PID $!"
fi
