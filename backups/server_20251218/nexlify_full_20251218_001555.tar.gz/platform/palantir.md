# Datos de Conexión - NomiPro.com

## SSH

| Parámetro | Valor |
|-----------|-------|
| Host | 185.68.111.228 |
| Puerto | 50050 |
| Usuario | nexlify.io |
| Password | @01Mwdsz4 |
| Directorio | /var/www/vhosts/nexlify.io |
| Directorio web | /var/www/vhosts/nexlify.io/httpdocs |

### Comandos de conexión

```bash
# Conectar por SSH
ssh -p 50050 nexlify.io@185.68.111.228

# Subir archivo con SCP
scp -P 50050 archivo.php nexlify.io@185.68.111.228:httpdocs/

# Subir directorio con SCP
scp -P 50050 -r directorio/ nexlify.io@185.68.111.228:httpdocs/
```

---

## MySQL

| Parámetro | Valor |
|-----------|-------|
| Host | localhost (desde el servidor) |
| Base de datos | nexlify_io |
| Usuario | nexlify_io |
| Password | @01Mwdsz4 |

### phpMyAdmin

- URL: https://dns111228.phdns6.es:8443/phpMyAdmin/index.php?db=nexlify_io

### Comandos desde el servidor

```bash
# Conectar a MySQL
mysql -u nexlify_io -p'@01Mwdsz4' nexlify_io

# Ejecutar query
mysql -u nexlify_io -p'@01Mwdsz4' nexlify_io -e "SELECT * FROM tabla;"

# Importar SQL
mysql -u nexlify_io -p'@01Mwdsz4' nexlify_io < archivo.sql

# Exportar base de datos
mysqldump -u nexlify_io -p'@01Mwdsz4' nexlify_io > backup.sql
```

---
Openai: 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

## Email SMTP

| Parámetro | Valor |
|-----------|-------|
| Host | nexlify.io |
| Puerto | 465 (SSL/TLS) |
| Usuario | noreply@nexlify.io |
| Password | Ak7o!6tN0G |
| Seguridad | SSL/TLS |
| From | "nexlify.io" <noreply@nexlify.io> |

### Uso en el código

El servicio de email está en `server/services/email.js` y usa Nodemailer.

```javascript
// Ejemplo de uso
const { sendPasswordResetEmail, sendWelcomeEmail, sendPasswordChangedEmail } = require('./services/email');

// Enviar email de recuperación de contraseña
await sendPasswordResetEmail(email, firstName, resetUrl);

// Enviar email de bienvenida
await sendWelcomeEmail(email, firstName, companyName);

// Enviar confirmación de cambio de contraseña
await sendPasswordChangedEmail(email, firstName);
```

### Configuración via variables de entorno (opcional)

```bash
SMTP_HOST=nexlify.io
SMTP_PORT=465
SMTP_USER=noreply@nexlify.io
SMTP_PASS=Ak7o!6tN0G
```

---

## Google OAuth

| Parámetro | Valor |
|-----------|-------|
| Client ID | 714077045276-g7fcq6ha25bbe012mbobv094ljm56ek3.apps.googleusercontent.com |
| Client Secret | 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 |
| Redirect URI | https://nexlify.io/api/auth/google/callback |
| Console | https://console.cloud.google.com/ |

### Configuración requerida en Google Cloud Console

**Authorized JavaScript origins:**
- `https://nexlify.io`

**Authorized redirect URIs:**
- `https://nexlify.io/api/auth/google/callback`

### Variables de entorno

```bash
# Backend (.env.production)
GOOGLE_CLIENT_ID=714077045276-g7fcq6ha25bbe012mbobv094ljm56ek3.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=https://nexlify.io/api/auth/google/callback

# Frontend (client/.env.production)
VITE_GOOGLE_CLIENT_ID=714077045276-g7fcq6ha25bbe012mbobv094ljm56ek3.apps.googleusercontent.com
```

---

## Stripe (Pagos y Suscripciones)

| Parámetro | Valor |
|-----------|-------|
| Secret Key | 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 |
| Publishable Key | pk_live_51NIoZLBMT9gV68TIkrd868F9EfcxjRcDFmTtskf9FO2AzoGAnW1avVJDhDLl7dEOnnuhiRreRHV5jbhrcXQDzbKD00pfrGQAQD |
| Webhook Secret | whsec_TjmCfsQjCQ5rXsHaQZQkk0qvEABEpuQV |
| Destination ID | we_1SbQXtBMT9gV68TIGs3X7WqJ |
| Webhook URL | https://nexlify.io/api/stripe/webhook |
| Dashboard | https://dashboard.stripe.com |

### Variables de entorno

```bash
STRIPE_SECRET_KEY=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
STRIPE_PUBLISHABLE_KEY=pk_live_51NIoZLBMT9gV68TIkrd868F9EfcxjRcDFmTtskf9FO2AzoGAnW1avVJDhDLl7dEOnnuhiRreRHV5jbhrcXQDzbKD00pfrGQAQD
STRIPE_WEBHOOK_SECRET=whsec_TjmCfsQjCQ5rXsHaQZQkk0qvEABEpuQV
FRONTEND_URL=https://nexlify.io
```

### Endpoints API

| Endpoint | Descripción |
|----------|-------------|
| POST /api/stripe/create-checkout-session | Crear sesión de pago |
| GET /api/stripe/plans | Obtener planes disponibles |
| GET /api/stripe/subscription | Obtener suscripción actual |
| POST /api/stripe/create-portal-session | Acceder al portal de cliente |
| POST /api/stripe/webhook | Recibir eventos de Stripe |

### Configuración del Webhook en Stripe

1. Ir a https://dashboard.stripe.com/webhooks
2. Añadir endpoint: `https://nexlify.io/api/stripe/webhook`
3. Seleccionar eventos:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.paid`
   - `invoice.payment_failed`

---

## Notas

- El servidor usa Plesk
- FTP requiere SSL/TLS (FTPS)
- La base de datos MySQL solo es accesible desde localhost (dentro del servidor)
- El email SMTP usa certificado SSL de Plesk
- Google OAuth requiere configurar los URIs autorizados en Google Cloud Console
- Stripe webhook requiere configurar el endpoint en el dashboard de Stripe

---

*Última actualización: 2025-12-07*
